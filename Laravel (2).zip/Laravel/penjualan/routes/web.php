<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\formcontroller;
use App\Http\Controllers\ForminputController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProdukController;
use App\Http\Controllers\FrontendController;
use App\Http\controllers\AboutController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/salam',function(){
    return view('salam', [
        "nama" =>"patia",
        "umur" =>20
    ]); 
});

Route::get('/nilai',function(){
    return view('nilai');
});
 
Route::get('/form_periksa',function(){
    return view('form_periksa');
});


Route::get('/form',[formcontroller::class,'index']);
Route::post('/hasil',[formcontroller::class,'hasil']);

Route::get('/form_input',[ForminputController::class,'index']);
Route::post('/input',[ForminputController::class,'input']);

//route admin
Route::prefix('admin')->group(function(){
    Route::get('/dashboard',[DashboardController::class,'index']);
    Route::get('/produk',[ProdukController::class,'index']);

});

//route front
Route::prefix('front')->group(function(){
    Route::get('/home',[FrontendController::class,'index']);
    Route::get('/about',[AboutController::class,'index']);
});