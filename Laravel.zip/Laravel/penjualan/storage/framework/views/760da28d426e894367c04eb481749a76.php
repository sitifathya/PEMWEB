

<?php $__env->startSection('content'); ?>

    ini adalah halaman dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\Laravel\penjualan\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>