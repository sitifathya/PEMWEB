@extends('admin.layout.app')

@section('content')
{{-- nama section halaman --}}
    ini adalah halaman dashboard
@endsection